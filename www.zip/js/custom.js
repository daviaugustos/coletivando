$(document).on('click', '.categoria-icon', function(){
    $("p", this).toggleClass('selected');
})


/* Cadastros */ 

/*
$(document).focus('#telefone', function(){
    $("#telefone").mask("(99)999-9999");
   
});


jQuery(function($){
   $("#date").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#telefone").mask("(999)999-9999");
   $("#tin").mask("99-9999999");
   $("#ssn").mask("999-99-9999");
});

jQuery(function($){
   $("#telefone").mask("(99) 999-9999");
});

    
*/